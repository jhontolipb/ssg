"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { formatDate, getUserRolePermissions } from "@/lib/utils"
import { Calendar, Clock, MapPin, Plus, Users } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

export default function EventsPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [events, setEvents] = useState<any[]>([])
  const [myEvents, setMyEvents] = useState<any[]>([])
  const [organizations, setOrganizations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    eventDate: "",
    eventTime: "",
    location: "",
    organizationId: "",
    isMandatory: false,
    sanctionPoints: 0,
  })

  // For demo purposes, let's assume the user role
  const userRole = user?.user_metadata?.role || "student"
  const permissions = getUserRolePermissions(userRole)

  useEffect(() => {
    if (!user) return

    const fetchEvents = async () => {
      setLoading(true)
      try {
        // Fetch all upcoming events
        const { data: eventsData, error: eventsError } = await supabase
          .from("events")
          .select(`
            id, 
            title, 
            description,
            event_date,
            created_by,
            org_id,
            is_mandatory,
            sanction_points,
            organizations(id, name, type, department)
          `)
          .gte("event_date", new Date().toISOString())
          .order("event_date")

        if (eventsError) throw eventsError
        setEvents(eventsData || [])

        // Fetch events where the user has attendance
        const { data: myEventsData, error: myEventsError } = await supabase
          .from("attendance")
          .select(`
            event_id,
            events(
              id, 
              title, 
              description,
              event_date,
              created_by,
              org_id,
              is_mandatory,
              sanction_points,
              organizations(id, name, type, department)
            )
          `)
          .eq("user_id", user.id)

        if (myEventsError) throw myEventsError

        // Transform the data to get the events
        const myEventsTransformed = myEventsData?.map((item) => item.events).filter(Boolean) || []

        setMyEvents(myEventsTransformed)

        // Fetch organizations for the create event form
        if (permissions.canCreateEvents) {
          const { data: orgsData, error: orgsError } = await supabase
            .from("organizations")
            .select("id, name, type, department")

          if (orgsError) throw orgsError
          setOrganizations(orgsData || [])
        }
      } catch (error) {
        console.error("Error fetching events:", error)
        toast({
          title: "Error",
          description: "Failed to load events. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchEvents()
  }, [supabase, user, toast, permissions.canCreateEvents])

  const handleCreateEvent = async () => {
    if (!user) return

    try {
      const eventDateTime = `${formData.eventDate}T${formData.eventTime}:00`

      const { data, error } = await supabase
        .from("events")
        .insert({
          title: formData.title,
          description: formData.description,
          event_date: eventDateTime,
          created_by: user.id,
          org_id: formData.organizationId,
          is_mandatory: formData.isMandatory,
          sanction_points: formData.sanctionPoints,
        })
        .select()

      if (error) throw error

      toast({
        title: "Event Created",
        description: "Your event has been created successfully.",
      })

      // Reset form and close dialog
      setFormData({
        title: "",
        description: "",
        eventDate: "",
        eventTime: "",
        location: "",
        organizationId: "",
        isMandatory: false,
        sanctionPoints: 0,
      })
      setCreateDialogOpen(false)

      // Refresh events list
      const { data: eventsData, error: eventsError } = await supabase
        .from("events")
        .select(`
          id, 
          title, 
          description,
          event_date,
          created_by,
          org_id,
          is_mandatory,
          sanction_points,
          organizations(id, name, type, department)
        `)
        .gte("event_date", new Date().toISOString())
        .order("event_date")

      if (eventsError) throw eventsError
      setEvents(eventsData || [])
    } catch (error: any) {
      console.error("Error creating event:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to create event. Please try again.",
        variant: "destructive",
      })
    }
  }

  const renderEventCard = (event: any) => (
    <Card key={event.id} className="overflow-hidden">
      <CardHeader className="pb-2">
        <CardTitle>{event.title}</CardTitle>
        <CardDescription>
          {event.organizations?.name} • {formatDate(event.event_date)}
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <p className="text-sm text-muted-foreground mb-4">{event.description}</p>
        <div className="grid grid-cols-1 gap-2 text-sm">
          <div className="flex items-center">
            <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
            <span>{new Date(event.event_date).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center">
            <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
            <span>{new Date(event.event_date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
            <span>Campus Auditorium</span>
          </div>
          <div className="flex items-center">
            <Users className="mr-2 h-4 w-4 text-muted-foreground" />
            <span>{event.organizations?.department || "All Departments"}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between pt-2">
        {event.is_mandatory && (
          <span className="text-xs bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400 px-2 py-1 rounded-full">
            Mandatory • {event.sanction_points} points
          </span>
        )}
        <Button variant="outline" size="sm" className="ml-auto">
          View Details
        </Button>
      </CardFooter>
    </Card>
  )

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Events</h1>
            <p className="text-muted-foreground">View and manage upcoming events</p>
          </div>
          {permissions.canCreateEvents && (
            <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Event
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Create New Event</DialogTitle>
                  <DialogDescription>
                    Fill in the details to create a new event for your organization.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">Event Title</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Enter event title"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Enter event description"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="event-date">Date</Label>
                      <Input
                        id="event-date"
                        type="date"
                        value={formData.eventDate}
                        onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="event-time">Time</Label>
                      <Input
                        id="event-time"
                        type="time"
                        value={formData.eventTime}
                        onChange={(e) => setFormData({ ...formData, eventTime: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="Enter event location"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="organization">Organization</Label>
                    <Select
                      value={formData.organizationId}
                      onValueChange={(value) => setFormData({ ...formData, organizationId: value })}
                    >
                      <SelectTrigger id="organization">
                        <SelectValue placeholder="Select organization" />
                      </SelectTrigger>
                      <SelectContent>
                        {organizations.map((org) => (
                          <SelectItem key={org.id} value={org.id}>
                            {org.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="mandatory"
                      checked={formData.isMandatory}
                      onCheckedChange={(checked) => setFormData({ ...formData, isMandatory: checked })}
                    />
                    <Label htmlFor="mandatory">Mandatory Attendance</Label>
                  </div>
                  {formData.isMandatory && (
                    <div className="grid gap-2">
                      <Label htmlFor="sanction-points">Sanction Points</Label>
                      <Input
                        id="sanction-points"
                        type="number"
                        min="0"
                        value={formData.sanctionPoints}
                        onChange={(e) =>
                          setFormData({ ...formData, sanctionPoints: Number.parseInt(e.target.value) || 0 })
                        }
                        placeholder="Points for non-attendance"
                      />
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateEvent}>Create Event</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <Tabs defaultValue="upcoming" className="space-y-4">
          <TabsList>
            <TabsTrigger value="upcoming">Upcoming Events</TabsTrigger>
            <TabsTrigger value="my-events">My Events</TabsTrigger>
          </TabsList>
          <TabsContent value="upcoming" className="space-y-4">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-4"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2 w-1/2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2 w-2/3"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2 w-1/2"></div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/3 ml-auto"></div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : events.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">{events.map(renderEventCard)}</div>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-10">
                  <Calendar className="h-10 w-10 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium mb-2">No upcoming events</p>
                  <p className="text-sm text-muted-foreground text-center max-w-md">
                    There are no upcoming events scheduled at this time. Check back later or contact your organization
                    admin.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          <TabsContent value="my-events" className="space-y-4">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[1, 2].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-4"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2 w-1/2"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2 w-2/3"></div>
                    </CardContent>
                    <CardFooter className="pt-2">
                      <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/3 ml-auto"></div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : myEvents.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myEvents.map(renderEventCard)}
              </div>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-10">
                  <Calendar className="h-10 w-10 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium mb-2">No events found</p>
                  <p className="text-sm text-muted-foreground text-center max-w-md">
                    You haven't attended any events yet. Browse upcoming events and participate to see them here.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
