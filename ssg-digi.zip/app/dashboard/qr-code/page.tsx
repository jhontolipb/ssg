"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { QRCodeSVG } from "qrcode.react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export default function QRCodePage() {
  const { supabase, user } = useSupabase()
  const [qrCode, setQrCode] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")

  useEffect(() => {
    if (!user) return

    const fetchUserData = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase.from("users").select("qr_code, name").eq("id", user.id).single()

        if (error) throw error

        if (data) {
          setQrCode(data.qr_code)
          setUserName(data.name)
        }
      } catch (error) {
        console.error("Error fetching QR code:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [supabase, user])

  const downloadQRCode = () => {
    if (!qrCode) return

    const canvas = document.getElementById("qr-code-canvas") as HTMLCanvasElement
    if (!canvas) return

    const url = canvas.toDataURL("image/png")
    const link = document.createElement("a")
    link.href = url
    link.download = `ssg-digi-qrcode-${userName.replace(/\s+/g, "-").toLowerCase()}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Your QR Code</h1>
          <p className="text-muted-foreground">Use this QR code for event attendance and identification</p>
        </div>

        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Student Identification QR</CardTitle>
            <CardDescription>
              Present this QR code to the Officer-in-Charge at events for attendance tracking
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center space-y-6">
            {loading ? (
              <div className="w-64 h-64 bg-gray-100 dark:bg-gray-800 animate-pulse rounded-lg"></div>
            ) : qrCode ? (
              <div className="bg-white p-4 rounded-lg">
                <QRCodeSVG id="qr-code-canvas" value={qrCode} size={256} level="H" includeMargin={true} />
              </div>
            ) : (
              <div className="text-center p-4">
                <p className="text-red-500">QR code not found. Please contact an administrator.</p>
              </div>
            )}

            <div className="text-center">
              <p className="font-medium text-lg">{userName}</p>
              <p className="text-sm text-muted-foreground">{qrCode}</p>
            </div>

            <Button onClick={downloadQRCode} disabled={!qrCode || loading} className="w-full">
              <Download className="mr-2 h-4 w-4" />
              Download QR Code
            </Button>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
