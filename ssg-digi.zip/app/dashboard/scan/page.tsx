"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { Camera, Check, X } from "lucide-react"
import { Html5Qrcode } from "html5-qrcode"

export default function ScanPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [scanning, setScanning] = useState(false)
  const [selectedEvent, setSelectedEvent] = useState<string>("")
  const [events, setEvents] = useState<any[]>([])
  const [scannedUser, setScannedUser] = useState<any>(null)
  const [attendanceType, setAttendanceType] = useState<"in" | "out">("in")
  const [loading, setLoading] = useState(false)
  const [loadingEvents, setLoadingEvents] = useState(true)
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const scannerDivRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchEvents = async () => {
      if (!user) return

      setLoadingEvents(true)
      try {
        // Get events where the current user is an officer
        const { data, error } = await supabase
          .from("events")
          .select(`
            id,
            title,
            event_date,
            organizations(name)
          `)
          .gte("event_date", new Date().toISOString().split("T")[0])
          .order("event_date")

        if (error) throw error
        setEvents(data || [])
      } catch (error) {
        console.error("Error fetching events:", error)
        toast({
          title: "Error",
          description: "Failed to load events. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoadingEvents(false)
      }
    }

    fetchEvents()

    // Cleanup scanner on unmount
    return () => {
      if (scannerRef.current) {
        scannerRef.current.stop().catch(console.error)
      }
    }
  }, [supabase, user, toast])

  const startScanner = async () => {
    if (!selectedEvent) {
      toast({
        title: "Error",
        description: "Please select an event first",
        variant: "destructive",
      })
      return
    }

    if (!scannerDivRef.current) return

    try {
      const scanner = new Html5Qrcode("qr-reader")
      scannerRef.current = scanner

      setScanning(true)
      await scanner.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        onScanSuccess,
        onScanFailure,
      )
    } catch (error) {
      console.error("Error starting scanner:", error)
      setScanning(false)
      toast({
        title: "Scanner Error",
        description: "Could not access camera. Please check permissions.",
        variant: "destructive",
      })
    }
  }

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.stop().catch(console.error)
      setScanning(false)
    }
  }

  const onScanSuccess = async (decodedText: string) => {
    // Stop scanning temporarily to process this code
    if (scannerRef.current) {
      scannerRef.current.pause()
    }

    setLoading(true)
    try {
      // Look up the user by QR code
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("id, name, department, email")
        .eq("qr_code", decodedText)
        .single()

      if (userError || !userData) {
        throw new Error("Invalid QR code or user not found")
      }

      setScannedUser(userData)

      // Check if user already has attendance for this event
      const { data: existingAttendance, error: attendanceError } = await supabase
        .from("attendance")
        .select("id, time_in, time_out, status")
        .eq("event_id", selectedEvent)
        .eq("user_id", userData.id)
        .maybeSingle()

      if (attendanceError) throw attendanceError

      const now = new Date().toISOString()

      if (attendanceType === "in") {
        // Handle check-in
        if (existingAttendance && existingAttendance.time_in) {
          toast({
            title: "Already checked in",
            description: `${userData.name} is already checked in to this event.`,
            variant: "default",
          })
        } else {
          // Create new attendance record
          const { error: insertError } = await supabase.from("attendance").upsert({
            event_id: selectedEvent,
            user_id: userData.id,
            recorded_by: user?.id || "",
            time_in: now,
            status: "present",
          })

          if (insertError) throw insertError

          toast({
            title: "Check-in successful",
            description: `${userData.name} has been checked in.`,
            variant: "default",
          })
        }
      } else {
        // Handle check-out
        if (!existingAttendance || !existingAttendance.time_in) {
          toast({
            title: "Not checked in",
            description: `${userData.name} has not checked in to this event yet.`,
            variant: "destructive",
          })
        } else if (existingAttendance.time_out) {
          toast({
            title: "Already checked out",
            description: `${userData.name} has already checked out from this event.`,
            variant: "default",
          })
        } else {
          // Update attendance record with check-out time
          const { error: updateError } = await supabase
            .from("attendance")
            .update({
              time_out: now,
            })
            .eq("id", existingAttendance.id)

          if (updateError) throw updateError

          toast({
            title: "Check-out successful",
            description: `${userData.name} has been checked out.`,
            variant: "default",
          })
        }
      }
    } catch (error: any) {
      console.error("Error processing QR code:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to process QR code",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      // Resume scanning after a short delay
      setTimeout(() => {
        if (scannerRef.current && scanning) {
          scannerRef.current.resume()
        }
      }, 2000)
    }
  }

  const onScanFailure = (error: string) => {
    // Don't show errors for normal scanning failures
    console.debug("QR scan failure:", error)
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Scan Attendance</h1>
          <p className="text-muted-foreground">Scan student QR codes to record event attendance</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Attendance Scanner</CardTitle>
            <CardDescription>Select an event and scan student QR codes to record attendance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="event">Select Event</Label>
              <Select disabled={scanning || loadingEvents} value={selectedEvent} onValueChange={setSelectedEvent}>
                <SelectTrigger id="event">
                  <SelectValue placeholder="Select an event" />
                </SelectTrigger>
                <SelectContent>
                  {loadingEvents ? (
                    <SelectItem value="loading" disabled>
                      Loading events...
                    </SelectItem>
                  ) : events.length > 0 ? (
                    events.map((event) => (
                      <SelectItem key={event.id} value={event.id}>
                        {event.title} ({event.organizations?.name})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No upcoming events found
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="attendance-type">Attendance Type</Label>
              <Select
                disabled={scanning}
                value={attendanceType}
                onValueChange={(value) => setAttendanceType(value as "in" | "out")}
              >
                <SelectTrigger id="attendance-type">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">Check In</SelectItem>
                  <SelectItem value="out">Check Out</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-center">
              {scanning ? (
                <Button variant="destructive" onClick={stopScanner}>
                  Stop Scanner
                </Button>
              ) : (
                <Button onClick={startScanner} disabled={!selectedEvent || loadingEvents}>
                  <Camera className="mr-2 h-4 w-4" />
                  Start Scanner
                </Button>
              )}
            </div>

            <div
              id="qr-reader"
              ref={scannerDivRef}
              className="w-full max-w-sm mx-auto overflow-hidden rounded-lg"
              style={{ height: scanning ? "300px" : "0" }}
            ></div>

            {scannedUser && (
              <Card className="border-2 border-primary">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Scanned Student</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="font-medium">Name:</span>
                      <span>{scannedUser.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Department:</span>
                      <span>{scannedUser.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Status:</span>
                      <span className="flex items-center">
                        {loading ? (
                          "Processing..."
                        ) : (
                          <>
                            {attendanceType === "in" ? (
                              <>
                                <Check className="mr-1 h-4 w-4 text-green-500" />
                                Checked In
                              </>
                            ) : (
                              <>
                                <X className="mr-1 h-4 w-4 text-red-500" />
                                Checked Out
                              </>
                            )}
                          </>
                        )}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-2">
              <Label htmlFor="manual-entry">Manual Entry</Label>
              <div className="flex gap-2">
                <Input id="manual-entry" placeholder="Enter QR code manually" disabled={scanning || loading} />
                <Button
                  variant="outline"
                  disabled={scanning || loading}
                  onClick={() => {
                    const input = document.getElementById("manual-entry") as HTMLInputElement
                    if (input.value) {
                      onScanSuccess(input.value)
                      input.value = ""
                    } else {
                      toast({
                        title: "Error",
                        description: "Please enter a QR code value",
                        variant: "destructive",
                      })
                    }
                  }}
                >
                  Submit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
