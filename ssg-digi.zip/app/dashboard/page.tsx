"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { formatDate } from "@/lib/utils"
import { CalendarCheck, ClipboardCheck, Users } from "lucide-react"

export default function DashboardPage() {
  const { supabase, user } = useSupabase()
  const [stats, setStats] = useState({
    upcomingEvents: 0,
    pendingClearances: 0,
    totalPoints: 0,
  })
  const [recentEvents, setRecentEvents] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    const fetchDashboardData = async () => {
      setLoading(true)
      try {
        // Fetch user profile to get points
        const { data: userData } = await supabase.from("users").select("points").eq("id", user.id).single()

        // Fetch upcoming events count
        const now = new Date().toISOString()
        const { count: upcomingEventsCount } = await supabase
          .from("events")
          .select("*", { count: "exact", head: true })
          .gt("event_date", now)

        // Fetch pending clearances count
        const { count: pendingClearancesCount } = await supabase
          .from("clearances")
          .select("*", { count: "exact", head: true })
          .eq("user_id", user.id)
          .eq("status", "pending")

        // Fetch recent events
        const { data: eventsData } = await supabase
          .from("events")
          .select(`
            id, 
            title, 
            event_date,
            organizations(name)
          `)
          .order("event_date", { ascending: false })
          .limit(5)

        setStats({
          upcomingEvents: upcomingEventsCount || 0,
          pendingClearances: pendingClearancesCount || 0,
          totalPoints: userData?.points || 0,
        })

        setRecentEvents(eventsData || [])
      } catch (error) {
        console.error("Error fetching dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [supabase, user])

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's an overview of your student activities.</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Upcoming Events</CardTitle>
              <CalendarCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.upcomingEvents}</div>
              <p className="text-xs text-muted-foreground">Events that require your attendance</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Clearances</CardTitle>
              <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.pendingClearances}</div>
              <p className="text-xs text-muted-foreground">Clearances awaiting approval</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Points</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{loading ? "..." : stats.totalPoints}</div>
              <p className="text-xs text-muted-foreground">Points accumulated from events</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="events" className="space-y-4">
          <TabsList>
            <TabsTrigger value="events">Recent Events</TabsTrigger>
            <TabsTrigger value="clearances">Clearance Status</TabsTrigger>
          </TabsList>
          <TabsContent value="events" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Events</CardTitle>
                <CardDescription>The latest events from your organizations</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <p>Loading events...</p>
                ) : recentEvents.length > 0 ? (
                  <div className="space-y-4">
                    {recentEvents.map((event) => (
                      <div
                        key={event.id}
                        className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                      >
                        <div>
                          <p className="font-medium">{event.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {event.organizations?.name || "Unknown Organization"}
                          </p>
                        </div>
                        <div className="text-sm text-muted-foreground">{formatDate(event.event_date)}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No recent events found.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="clearances" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Clearance Status</CardTitle>
                <CardDescription>Status of your clearance requests</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">View and manage your clearance requests from the Clearance tab.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
