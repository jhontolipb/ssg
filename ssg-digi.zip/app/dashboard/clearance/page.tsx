"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { formatDate, generateTransactionCode, getUserRolePermissions } from "@/lib/utils"
import { Check, Download, FileText, X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { jsPDF } from "jspdf"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ClearancePage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [clearances, setClearances] = useState<any[]>([])
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false)
  const [selectedClearance, setSelectedClearance] = useState<any>(null)
  const [remarks, setRemarks] = useState("")
  const [approvalStatus, setApprovalStatus] = useState<"approved" | "rejected">("approved")
  const [organizations, setOrganizations] = useState<any[]>([])

  // For demo purposes, let's assume the user role
  const userRole = user?.user_metadata?.role || "student"
  const permissions = getUserRolePermissions(userRole)

  useEffect(() => {
    if (!user) return

    const fetchClearanceData = async () => {
      setLoading(true)
      try {
        // Fetch organizations for the student to request clearance from
        const { data: orgsData, error: orgsError } = await supabase
          .from("organizations")
          .select("id, name, type, department")

        if (orgsError) throw orgsError
        setOrganizations(orgsData || [])

        // Fetch user's clearances
        const { data: clearanceData, error: clearanceError } = await supabase
          .from("clearances")
          .select(`
            id,
            status,
            remarks,
            transaction_code,
            created_at,
            organizations(id, name, type, department)
          `)
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })

        if (clearanceError) throw clearanceError
        setClearances(clearanceData || [])

        // If user can approve clearances, fetch pending approvals
        if (permissions.canApproveClearance) {
          // Get organizations where user is admin
          const { data: adminOrgsData, error: adminOrgsError } = await supabase
            .from("organizations")
            .select("id")
            .eq("admin_id", user.id)

          if (adminOrgsError) throw adminOrgsError

          if (adminOrgsData && adminOrgsData.length > 0) {
            const orgIds = adminOrgsData.map((org) => org.id)

            // Fetch clearances for these organizations
            const { data: pendingData, error: pendingError } = await supabase
              .from("clearances")
              .select(`
                id,
                status,
                remarks,
                transaction_code,
                created_at,
                organizations(id, name, type, department),
                users(id, name, email, department)
              `)
              .in("org_id", orgIds)
              .eq("status", "pending")
              .order("created_at", { ascending: true })

            if (pendingError) throw pendingError
            setPendingApprovals(pendingData || [])
          }
        }
      } catch (error) {
        console.error("Error fetching clearance data:", error)
        toast({
          title: "Error",
          description: "Failed to load clearance data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchClearanceData()
  }, [supabase, user, toast, permissions.canApproveClearance])

  const requestClearance = async (orgId: string) => {
    if (!user) return

    try {
      // Check if there's already a pending clearance for this organization
      const { data: existingClearance, error: checkError } = await supabase
        .from("clearances")
        .select("id")
        .eq("user_id", user.id)
        .eq("org_id", orgId)
        .eq("status", "pending")
        .maybeSingle()

      if (checkError) throw checkError

      if (existingClearance) {
        toast({
          title: "Already Requested",
          description: "You already have a pending clearance request for this organization.",
          variant: "default",
        })
        return
      }

      // Create a new clearance request
      const transactionCode = generateTransactionCode()
      const { error: insertError } = await supabase.from("clearances").insert({
        user_id: user.id,
        org_id: orgId,
        status: "pending",
        transaction_code: transactionCode,
      })

      if (insertError) throw insertError

      toast({
        title: "Clearance Requested",
        description: "Your clearance request has been submitted successfully.",
      })

      // Refresh clearances
      const { data: clearanceData, error: clearanceError } = await supabase
        .from("clearances")
        .select(`
          id,
          status,
          remarks,
          transaction_code,
          created_at,
          organizations(id, name, type, department)
        `)
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (clearanceError) throw clearanceError
      setClearances(clearanceData || [])
    } catch (error: any) {
      console.error("Error requesting clearance:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to request clearance. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleApprovalAction = async () => {
    if (!selectedClearance) return

    try {
      const { error } = await supabase
        .from("clearances")
        .update({
          status: approvalStatus,
          remarks: remarks,
        })
        .eq("id", selectedClearance.id)

      if (error) throw error

      toast({
        title: approvalStatus === "approved" ? "Clearance Approved" : "Clearance Rejected",
        description: `The clearance request has been ${approvalStatus} successfully.`,
      })

      // Refresh pending approvals
      const { data: adminOrgsData } = await supabase.from("organizations").select("id").eq("admin_id", user?.id)

      if (adminOrgsData && adminOrgsData.length > 0) {
        const orgIds = adminOrgsData.map((org) => org.id)

        const { data: pendingData } = await supabase
          .from("clearances")
          .select(`
            id,
            status,
            remarks,
            transaction_code,
            created_at,
            organizations(id, name, type, department),
            users(id, name, email, department)
          `)
          .in("org_id", orgIds)
          .eq("status", "pending")
          .order("created_at", { ascending: true })

        setPendingApprovals(pendingData || [])
      }

      // Reset and close dialog
      setSelectedClearance(null)
      setRemarks("")
      setApprovalDialogOpen(false)
    } catch (error: any) {
      console.error("Error processing clearance:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to process clearance. Please try again.",
        variant: "destructive",
      })
    }
  }

  const generateClearanceDocument = () => {
    try {
      const doc = new jsPDF()

      // Add header
      doc.setFontSize(20)
      doc.text("SSG Digi - Student Clearance", 105, 20, { align: "center" })

      doc.setFontSize(12)
      doc.text("Supreme Student Government", 105, 30, { align: "center" })
      doc.text("Digital Student Governance Platform", 105, 38, { align: "center" })

      // Add student info
      doc.setFontSize(14)
      doc.text("Student Information", 20, 55)

      doc.setFontSize(12)
      doc.text(`Name: ${user?.user_metadata?.name || "Student Name"}`, 20, 65)
      doc.text(`Department: ${user?.user_metadata?.department || "Department"}`, 20, 75)
      doc.text(`Date Generated: ${new Date().toLocaleDateString()}`, 20, 85)

      // Add clearance info
      doc.setFontSize(14)
      doc.text("Clearance Status", 20, 105)

      doc.setFontSize(12)
      let yPos = 115

      // Check if all clearances are approved
      const allApproved = clearances.every((c) => c.status === "approved")

      if (allApproved) {
        doc.setTextColor(0, 128, 0) // Green color
        doc.text("✓ CLEARED", 105, yPos, { align: "center" })
        doc.setTextColor(0, 0, 0) // Reset to black
        yPos += 10
      } else {
        doc.setTextColor(255, 0, 0) // Red color
        doc.text("✗ NOT CLEARED", 105, yPos, { align: "center" })
        doc.setTextColor(0, 0, 0) // Reset to black
        yPos += 10
      }

      yPos += 10
      doc.text("Organization Clearances:", 20, yPos)
      yPos += 10

      // List all clearances
      clearances.forEach((clearance) => {
        const status =
          clearance.status === "approved" ? "✓ APPROVED" : clearance.status === "rejected" ? "✗ REJECTED" : "⟳ PENDING"

        doc.text(`${clearance.organizations.name}: ${status}`, 30, yPos)
        if (clearance.remarks) {
          yPos += 8
          doc.text(`Remarks: ${clearance.remarks}`, 40, yPos)
        }
        yPos += 10
      })

      // Add transaction code
      yPos += 20
      doc.text(`Transaction Code: ${clearances[0]?.transaction_code || generateTransactionCode()}`, 20, yPos)

      // Add verification note
      yPos += 20
      doc.setFontSize(10)
      doc.text("This document can be verified through the SSG Digi platform using the transaction code.", 105, yPos, {
        align: "center",
      })

      // Save the PDF
      doc.save("ssg-digi-clearance.pdf")

      toast({
        title: "Clearance Generated",
        description: "Your clearance document has been generated and downloaded.",
      })
    } catch (error) {
      console.error("Error generating clearance document:", error)
      toast({
        title: "Error",
        description: "Failed to generate clearance document. Please try again.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
            Approved
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">
            Rejected
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">
            Pending
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Clearance</h1>
            <p className="text-muted-foreground">Manage your clearance requests and approvals</p>
          </div>
          {clearances.length > 0 && clearances.some((c) => c.status === "approved") && (
            <Button onClick={generateClearanceDocument}>
              <Download className="mr-2 h-4 w-4" />
              Generate Clearance
            </Button>
          )}
        </div>

        {permissions.canApproveClearance ? (
          <Tabs defaultValue="my-clearances" className="space-y-4">
            <TabsList>
              <TabsTrigger value="my-clearances">My Clearances</TabsTrigger>
              <TabsTrigger value="pending-approvals">
                Pending Approvals
                {pendingApprovals.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {pendingApprovals.length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>
            <TabsContent value="my-clearances" className="space-y-4">
              {renderMyClearances()}
            </TabsContent>
            <TabsContent value="pending-approvals" className="space-y-4">
              {renderPendingApprovals()}
            </TabsContent>
          </Tabs>
        ) : (
          renderMyClearances()
        )}

        {/* Approval Dialog */}
        <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Process Clearance Request</DialogTitle>
              <DialogDescription>
                Review and process the clearance request from {selectedClearance?.users?.name}.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium mb-1">Student</p>
                  <p className="text-sm">{selectedClearance?.users?.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Department</p>
                  <p className="text-sm">{selectedClearance?.users?.department}</p>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium mb-1">Organization</p>
                <p className="text-sm">{selectedClearance?.organizations?.name}</p>
              </div>
              <div>
                <p className="text-sm font-medium mb-1">Request Date</p>
                <p className="text-sm">{selectedClearance ? formatDate(selectedClearance.created_at) : ""}</p>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="remarks">Remarks (Optional)</Label>
                <Textarea
                  id="remarks"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Add any comments or notes about this clearance"
                />
              </div>
              <div className="flex gap-4">
                <Button
                  variant={approvalStatus === "approved" ? "default" : "outline"}
                  className={approvalStatus === "approved" ? "w-full" : "w-full text-muted-foreground"}
                  onClick={() => setApprovalStatus("approved")}
                >
                  <Check className="mr-2 h-4 w-4" />
                  Approve
                </Button>
                <Button
                  variant={approvalStatus === "rejected" ? "destructive" : "outline"}
                  className={approvalStatus === "rejected" ? "w-full" : "w-full text-muted-foreground"}
                  onClick={() => setApprovalStatus("rejected")}
                >
                  <X className="mr-2 h-4 w-4" />
                  Reject
                </Button>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setApprovalDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleApprovalAction}>Submit</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )

  function renderMyClearances() {
    return (
      <>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-4"></div>
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/3 ml-auto"></div>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : clearances.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {clearances.map((clearance) => (
              <Card key={clearance.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{clearance.organizations.name}</CardTitle>
                  <CardDescription>
                    {clearance.organizations.type} • {clearance.organizations.department}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-muted-foreground">
                      Requested on {formatDate(clearance.created_at)}
                    </span>
                    {getStatusBadge(clearance.status)}
                  </div>
                  {clearance.remarks && (
                    <div className="text-sm">
                      <p className="font-medium">Remarks:</p>
                      <p className="text-muted-foreground">{clearance.remarks}</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="text-xs text-muted-foreground">Transaction: {clearance.transaction_code}</div>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-10">
              <FileText className="h-10 w-10 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">No clearance requests</p>
              <p className="text-sm text-muted-foreground text-center max-w-md mb-6">
                You haven't requested any clearances yet. Request clearance from your organizations to get started.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-md">
                {organizations.map((org) => (
                  <Button key={org.id} variant="outline" onClick={() => requestClearance(org.id)}>
                    Request from {org.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </>
    )
  }

  function renderPendingApprovals() {
    return (
      <>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2].map((i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-3/4"></div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse mb-4"></div>
                </CardContent>
                <CardFooter className="pt-2">
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded animate-pulse w-1/3 ml-auto"></div>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : pendingApprovals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {pendingApprovals.map((clearance) => (
              <Card key={clearance.id}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{clearance.users.name}</CardTitle>
                  <CardDescription>
                    {clearance.users.department} • {clearance.users.email}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-sm text-muted-foreground">
                      Requested on {formatDate(clearance.created_at)}
                    </span>
                    {getStatusBadge(clearance.status)}
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">Organization:</p>
                    <p className="text-muted-foreground">{clearance.organizations.name}</p>
                  </div>
                </CardContent>
                <CardFooter className="pt-2">
                  <Button
                    className="ml-auto"
                    onClick={() => {
                      setSelectedClearance(clearance)
                      setRemarks("")
                      setApprovalStatus("approved")
                      setApprovalDialogOpen(true)
                    }}
                  >
                    Process Request
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-10">
              <Check className="h-10 w-10 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">No pending approvals</p>
              <p className="text-sm text-muted-foreground text-center max-w-md">
                There are no clearance requests waiting for your approval at this time.
              </p>
            </CardContent>
          </Card>
        )}
      </>
    )
  }
}
