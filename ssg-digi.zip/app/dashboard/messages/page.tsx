"use client"

import { useEffect, useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { DashboardLayout } from "@/components/dashboard-layout"
import { useSupabase } from "@/lib/supabase-provider"
import { formatDate } from "@/lib/utils"
import { Send } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MessagesPage() {
  const { supabase, user } = useSupabase()
  const { toast } = useToast()
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [message, setMessage] = useState("")
  const [conversations, setConversations] = useState<any[]>([])
  const [activeConversation, setActiveConversation] = useState<string | null>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [organizations, setOrganizations] = useState<any[]>([])
  const [selectedOrg, setSelectedOrg] = useState<string>("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!user) return

    const fetchMessagesData = async () => {
      setLoading(true)
      try {
        // Fetch organizations
        const { data: orgsData, error: orgsError } = await supabase
          .from("organizations")
          .select("id, name, type, department")

        if (orgsError) throw orgsError
        setOrganizations(orgsData || [])

        // Fetch conversations (unique users the current user has messaged with)
        const { data: sentMessages, error: sentError } = await supabase
          .from("messages")
          .select(`
            id,
            recipient_id,
            users!messages_recipient_id_fkey(id, name, email)
          `)
          .eq("sender_id", user.id)
          .order("created_at", { ascending: false })

        if (sentError) throw sentError

        const { data: receivedMessages, error: receivedError } = await supabase
          .from("messages")
          .select(`
            id,
            sender_id,
            users!messages_sender_id_fkey(id, name, email)
          `)
          .eq("recipient_id", user.id)
          .order("created_at", { ascending: false })

        if (receivedError) throw receivedError

        // Combine and deduplicate conversations
        const uniqueConversations = new Map()

        sentMessages?.forEach((msg) => {
          const otherUserId = msg.recipient_id
          const otherUser = msg.users
          if (otherUser && !uniqueConversations.has(otherUserId)) {
            uniqueConversations.set(otherUserId, otherUser)
          }
        })

        receivedMessages?.forEach((msg) => {
          const otherUserId = msg.sender_id
          const otherUser = msg.users
          if (otherUser && !uniqueConversations.has(otherUserId)) {
            uniqueConversations.set(otherUserId, otherUser)
          }
        })

        setConversations(Array.from(uniqueConversations.values()))

        // If there are conversations, set the first one as active
        if (uniqueConversations.size > 0) {
          const firstConversationId = Array.from(uniqueConversations.keys())[0]
          setActiveConversation(firstConversationId)

          // Load messages for the first conversation
          await loadMessages(firstConversationId)
        }
      } catch (error) {
        console.error("Error fetching messages data:", error)
        toast({
          title: "Error",
          description: "Failed to load messages. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchMessagesData()

    // Set up real-time subscription for new messages
    const messagesSubscription = supabase
      .channel("messages-channel")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `sender_id=eq.${user.id}`,
        },
        (payload) => {
          handleNewMessage(payload.new)
        },
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `recipient_id=eq.${user.id}`,
        },
        (payload) => {
          handleNewMessage(payload.new)
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(messagesSubscription)
    }
  }, [supabase, user, toast])

  useEffect(() => {
    // Scroll to bottom when messages change
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleNewMessage = (newMessage: any) => {
    // If the message is part of the active conversation, add it to the messages
    if (
      activeConversation &&
      ((newMessage.sender_id === activeConversation && newMessage.recipient_id === user?.id) ||
        (newMessage.recipient_id === activeConversation && newMessage.sender_id === user?.id))
    ) {
      setMessages((prev) => [...prev, newMessage])
    }

    // Update unread count or other UI indicators
    // This would depend on your UI design
  }

  const loadMessages = async (conversationId: string) => {
    if (!user) return

    try {
      setActiveConversation(conversationId)

      // Fetch messages between current user and the selected user
      const { data, error } = await supabase
        .from("messages")
        .select(`
          id,
          sender_id,
          recipient_id,
          content,
          is_read,
          created_at,
          users!messages_sender_id_fkey(id, name, email)
        `)
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${conversationId}),and(sender_id.eq.${conversationId},recipient_id.eq.${user.id})`,
        )
        .order("created_at", { ascending: true })

      if (error) throw error

      setMessages(data || [])

      // Mark messages as read
      const unreadMessages =
        data?.filter((msg) => msg.recipient_id === user.id && !msg.is_read).map((msg) => msg.id) || []

      if (unreadMessages.length > 0) {
        await supabase.from("messages").update({ is_read: true }).in("id", unreadMessages)
      }
    } catch (error) {
      console.error("Error loading messages:", error)
      toast({
        title: "Error",
        description: "Failed to load conversation. Please try again.",
        variant: "destructive",
      })
    }
  }

  const startNewConversation = async () => {
    if (!selectedOrg) {
      toast({
        title: "Error",
        description: "Please select an organization to message.",
        variant: "destructive",
      })
      return
    }

    try {
      // Get the admin of the selected organization
      const { data, error } = await supabase
        .from("organizations")
        .select("admin_id, users!organizations_admin_id_fkey(id, name, email)")
        .eq("id", selectedOrg)
        .single()

      if (error) throw error

      if (!data.admin_id) {
        toast({
          title: "Error",
          description: "This organization doesn't have an admin to message.",
          variant: "destructive",
        })
        return
      }

      // Check if this admin is already in conversations
      const existingConversation = conversations.find((c) => c.id === data.admin_id)

      if (!existingConversation) {
        // Add to conversations list
        setConversations((prev) => [...prev, data.users])
      }

      // Set as active conversation
      setActiveConversation(data.admin_id)

      // Load messages
      await loadMessages(data.admin_id)

      // Reset selection
      setSelectedOrg("")
    } catch (error) {
      console.error("Error starting new conversation:", error)
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive",
      })
    }
  }

  const sendMessage = async () => {
    if (!user || !activeConversation || !message.trim()) return

    setSending(true)
    try {
      const { error } = await supabase.from("messages").insert({
        sender_id: user.id,
        recipient_id: activeConversation,
        content: message.trim(),
        is_read: false,
      })

      if (error) throw error

      // Clear input
      setMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSending(false)
    }
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col gap-6 h-[calc(100vh-120px)]">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
          <p className="text-muted-foreground">Communicate with organizations and administrators</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1 min-h-0">
          {/* Conversations Sidebar */}
          <Card className="md:col-span-1 flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Conversations</CardTitle>
              <CardDescription>Your message history</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 flex-1 overflow-y-auto">
              <div className="flex gap-2">
                <Select value={selectedOrg} onValueChange={setSelectedOrg}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Message an organization" />
                  </SelectTrigger>
                  <SelectContent>
                    {organizations.map((org) => (
                      <SelectItem key={org.id} value={org.id}>
                        {org.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button size="icon" onClick={startNewConversation} disabled={!selectedOrg}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                {loading ? (
                  Array(3)
                    .fill(0)
                    .map((_, i) => (
                      <div key={i} className="flex items-center gap-3 p-2 rounded-md animate-pulse">
                        <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                        <div className="space-y-2 flex-1">
                          <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                          <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                        </div>
                      </div>
                    ))
                ) : conversations.length > 0 ? (
                  conversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 ${
                        activeConversation === conversation.id ? "bg-gray-100 dark:bg-gray-800" : ""
                      }`}
                      onClick={() => loadMessages(conversation.id)}
                    >
                      <Avatar>
                        <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={conversation.name} />
                        <AvatarFallback>{getInitials(conversation.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{conversation.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{conversation.email}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-muted-foreground">No conversations yet</div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Messages Area */}
          <Card className="md:col-span-3 flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">
                {activeConversation
                  ? conversations.find((c) => c.id === activeConversation)?.name || "Messages"
                  : "Messages"}
              </CardTitle>
              <CardDescription>
                {activeConversation
                  ? conversations.find((c) => c.id === activeConversation)?.email || ""
                  : "Select a conversation to start messaging"}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto flex flex-col">
              {loading ? (
                <div className="flex-1 flex items-center justify-center">
                  <p>Loading messages...</p>
                </div>
              ) : !activeConversation ? (
                <div className="flex-1 flex items-center justify-center">
                  <p className="text-muted-foreground">Select a conversation to view messages</p>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex-1 flex items-center justify-center">
                  <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
                </div>
              ) : (
                <div className="space-y-4 flex-1">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender_id === user?.id ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] px-4 py-2 rounded-lg ${
                          msg.sender_id === user?.id ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p>{msg.content}</p>
                        <p
                          className={`text-xs mt-1 ${
                            msg.sender_id === user?.id ? "text-primary-foreground/70" : "text-muted-foreground"
                          }`}
                        >
                          {formatDate(msg.created_at)}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </CardContent>
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  placeholder="Type your message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault()
                      sendMessage()
                    }
                  }}
                  disabled={!activeConversation || sending}
                />
                <Button size="icon" onClick={sendMessage} disabled={!activeConversation || !message.trim() || sending}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
