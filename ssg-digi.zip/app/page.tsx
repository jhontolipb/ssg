import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CalendarCheck, ClipboardCheck, MessageSquare, QrCode, Shield } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

export default function Home() {
  const isSupabaseConfigured =
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_URL !== "https://placeholder-url.supabase.co"

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SSG Digi</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">Student Governance Platform</p>
          </div>
          <div className="flex gap-4">
            <Link href="/login">
              <Button variant="outline">Log In</Button>
            </Link>
            <Link href="/register">
              <Button>Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {!isSupabaseConfigured && (
          <div className="container mx-auto px-4 py-4">
            <Alert variant="warning">
              <InfoIcon className="h-4 w-4" />
              <AlertTitle>Supabase Integration Required</AlertTitle>
              <AlertDescription>
                Please add Supabase integration to enable authentication and database functionality. Set the
                NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables.
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-b from-white to-gray-100 dark:from-gray-800 dark:to-gray-900">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-900 dark:text-white">
              Digital Student Governance Platform
            </h1>
            <p className="text-xl mb-10 max-w-3xl mx-auto text-gray-600 dark:text-gray-300">
              Streamline student records, event attendance, communication, and clearance processing across departments
              and organizations.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/register">
                <Button size="lg" className="px-8">
                  Get Started
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="px-8">
                  Log In
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white dark:bg-gray-800">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">Key Features</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <FeatureCard
                icon={QrCode}
                title="QR-Based Attendance"
                description="Easily track event attendance with QR code scanning for seamless check-in and check-out."
              />
              <FeatureCard
                icon={ClipboardCheck}
                title="Digital Clearance"
                description="Request and approve clearances digitally with a unified document system and verification."
              />
              <FeatureCard
                icon={CalendarCheck}
                title="Event Management"
                description="Create, manage, and track participation in organizational events across campus."
              />
              <FeatureCard
                icon={MessageSquare}
                title="Secure Messaging"
                description="Real-time communication between students and organizations with notifications."
              />
              <FeatureCard
                icon={Shield}
                title="Role-Based Access"
                description="Secure access controls for different roles from Super Admin to Students."
              />
              <FeatureCard
                icon={CalendarCheck}
                title="Sanctions Management"
                description="Automated tracking of event participation and associated sanctions for clearance."
              />
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-100 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-600 dark:text-gray-300">
            © {new Date().getFullYear()} SSG Digi. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

interface FeatureCardProps {
  icon: React.ElementType
  title: string
  description: string
}

function FeatureCard({ icon: Icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg border border-gray-200 dark:border-gray-600">
      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300">{description}</p>
    </div>
  )
}
