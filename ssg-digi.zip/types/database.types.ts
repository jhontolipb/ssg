export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          name: string
          department: string
          role: string
          qr_code: string
          points: number
          created_at: string
        }
        Insert: {
          id?: string
          email: string
          name: string
          department: string
          role: string
          qr_code?: string
          points?: number
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          department?: string
          role?: string
          qr_code?: string
          points?: number
          created_at?: string
        }
      }
      organizations: {
        Row: {
          id: string
          name: string
          type: string
          admin_id: string
          department: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          type: string
          admin_id: string
          department: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          type?: string
          admin_id?: string
          department?: string
          created_at?: string
        }
      }
      events: {
        Row: {
          id: string
          title: string
          description: string
          event_date: string
          created_by: string
          org_id: string
          sanction_points: number
          is_mandatory: boolean
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description: string
          event_date: string
          created_by: string
          org_id: string
          sanction_points: number
          is_mandatory: boolean
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string
          event_date?: string
          created_by?: string
          org_id?: string
          sanction_points?: number
          is_mandatory?: boolean
          created_at?: string
        }
      }
      attendance: {
        Row: {
          id: string
          event_id: string
          user_id: string
          recorded_by: string
          time_in: string
          time_out: string | null
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          event_id: string
          user_id: string
          recorded_by: string
          time_in: string
          time_out?: string | null
          status: string
          created_at?: string
        }
        Update: {
          id?: string
          event_id?: string
          user_id?: string
          recorded_by?: string
          time_in?: string
          time_out?: string | null
          status?: string
          created_at?: string
        }
      }
      clearances: {
        Row: {
          id: string
          user_id: string
          org_id: string
          status: string
          remarks: string | null
          transaction_code: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          org_id: string
          status: string
          remarks?: string | null
          transaction_code: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          org_id?: string
          status?: string
          remarks?: string | null
          transaction_code?: string
          created_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          sender_id: string
          recipient_id: string
          content: string
          is_read: boolean
          created_at: string
        }
        Insert: {
          id?: string
          sender_id: string
          recipient_id: string
          content: string
          is_read?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          sender_id?: string
          recipient_id?: string
          content?: string
          is_read?: boolean
          created_at?: string
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          title: string
          content: string
          is_read: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          content: string
          is_read?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          content?: string
          is_read?: boolean
          created_at?: string
        }
      }
    }
  }
}
