"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  BarChart3,
  Calendar,
  ClipboardCheck,
  LogOut,
  Menu,
  MessageSquare,
  QrCode,
  Settings,
  Users,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useSupabase } from "@/lib/supabase-provider"
import { getUserRolePermissions, ROLES } from "@/lib/utils"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const pathname = usePathname()
  const { user, supabase } = useSupabase()
  const [open, setOpen] = useState(false)

  // For demo purposes, let's assume the user role
  const userRole = user?.user_metadata?.role || ROLES.STUDENT
  const permissions = getUserRolePermissions(userRole)

  const handleSignOut = async () => {
    await supabase.auth.signOut()
  }

  const routes = [
    {
      label: "Dashboard",
      href: "/dashboard",
      icon: BarChart3,
      active: pathname === "/dashboard",
      visible: true,
    },
    {
      label: "Events",
      href: "/dashboard/events",
      icon: Calendar,
      active: pathname === "/dashboard/events",
      visible: true,
    },
    {
      label: "Clearance",
      href: "/dashboard/clearance",
      icon: ClipboardCheck,
      active: pathname === "/dashboard/clearance",
      visible: true,
    },
    {
      label: "Messages",
      href: "/dashboard/messages",
      icon: MessageSquare,
      active: pathname === "/dashboard/messages",
      visible: true,
    },
    {
      label: "QR Code",
      href: "/dashboard/qr-code",
      icon: QrCode,
      active: pathname === "/dashboard/qr-code",
      visible: userRole === ROLES.STUDENT,
    },
    {
      label: "Scan Attendance",
      href: "/dashboard/scan",
      icon: QrCode,
      active: pathname === "/dashboard/scan",
      visible: permissions.canScanAttendance,
    },
    {
      label: "Users",
      href: "/dashboard/users",
      icon: Users,
      active: pathname === "/dashboard/users",
      visible: permissions.canApproveAccounts || permissions.canViewAllRecords,
    },
    {
      label: "Organizations",
      href: "/dashboard/organizations",
      icon: Users,
      active: pathname === "/dashboard/organizations",
      visible: permissions.canCreateOrgs,
    },
    {
      label: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
      active: pathname === "/dashboard/settings",
      visible: true,
    },
  ]

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Sidebar for desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SSG Digi</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Student Governance Platform</p>
        </div>
        <nav className="flex-1 px-4 space-y-1">
          {routes.map(
            (route) =>
              route.visible && (
                <Link
                  key={route.href}
                  href={route.href}
                  className={`flex items-center px-4 py-3 text-sm rounded-md ${
                    route.active
                      ? "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                      : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                  }`}
                >
                  <route.icon className="w-5 h-5 mr-3" />
                  {route.label}
                </Link>
              ),
          )}
        </nav>
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <Button
            variant="ghost"
            className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={handleSignOut}
          >
            <LogOut className="w-5 h-5 mr-3" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Mobile sidebar */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden absolute top-4 left-4 z-50">
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle Menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-64">
          <div className="p-6 flex justify-between items-center">
            <h1 className="text-2xl font-bold">SSG Digi</h1>
            <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
              <X className="h-5 w-5" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
          <nav className="flex-1 px-4 space-y-1">
            {routes.map(
              (route) =>
                route.visible && (
                  <Link
                    key={route.href}
                    href={route.href}
                    className={`flex items-center px-4 py-3 text-sm rounded-md ${
                      route.active
                        ? "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                        : "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                    }`}
                    onClick={() => setOpen(false)}
                  >
                    <route.icon className="w-5 h-5 mr-3" />
                    {route.label}
                  </Link>
                ),
            )}
            <Button
              variant="ghost"
              className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 mt-4"
              onClick={handleSignOut}
            >
              <LogOut className="w-5 h-5 mr-3" />
              Sign Out
            </Button>
          </nav>
        </SheetContent>
      </Sheet>

      {/* Main content */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto">{children}</main>
    </div>
  )
}
