import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function generateTransactionCode(length = 10) {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let result = ""
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length))
  }
  return result
}

export function formatDate(date: Date | string) {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export const ROLES = {
  SUPER_ADMIN: "super_admin",
  DEPT_ADMIN: "dept_admin",
  CLUB_ADMIN: "club_admin",
  OFFICER: "officer",
  STUDENT: "student",
}

export function getUserRolePermissions(role: string) {
  switch (role) {
    case ROLES.SUPER_ADMIN:
      return {
        canApproveAccounts: true,
        canCreateOrgs: true,
        canCreateEvents: true,
        canAssignOfficers: true,
        canViewAllRecords: true,
        canApproveClearance: true,
        canAssignPoints: true,
        canScanAttendance: false,
      }
    case ROLES.DEPT_ADMIN:
      return {
        canApproveAccounts: true,
        canCreateOrgs: false,
        canCreateEvents: true,
        canAssignOfficers: true,
        canViewAllRecords: false,
        canApproveClearance: true,
        canAssignPoints: false,
        canScanAttendance: false,
      }
    case ROLES.CLUB_ADMIN:
      return {
        canApproveAccounts: false,
        canCreateOrgs: false,
        canCreateEvents: true,
        canAssignOfficers: true,
        canViewAllRecords: false,
        canApproveClearance: true,
        canAssignPoints: false,
        canScanAttendance: false,
      }
    case ROLES.OFFICER:
      return {
        canApproveAccounts: false,
        canCreateOrgs: false,
        canCreateEvents: false,
        canAssignOfficers: false,
        canViewAllRecords: false,
        canApproveClearance: false,
        canAssignPoints: false,
        canScanAttendance: true,
      }
    case ROLES.STUDENT:
      return {
        canApproveAccounts: false,
        canCreateOrgs: false,
        canCreateEvents: false,
        canAssignOfficers: false,
        canViewAllRecords: false,
        canApproveClearance: false,
        canAssignPoints: false,
        canScanAttendance: false,
      }
    default:
      return {
        canApproveAccounts: false,
        canCreateOrgs: false,
        canCreateEvents: false,
        canAssignOfficers: false,
        canViewAllRecords: false,
        canApproveClearance: false,
        canAssignPoints: false,
        canScanAttendance: false,
      }
  }
}
