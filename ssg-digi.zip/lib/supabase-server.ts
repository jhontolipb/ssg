import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import type { Database } from "@/types/database.types"

// Default Supabase URL and anon key with your credentials as fallback
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://rufrxqiapanvefswrpir.supabase.co"
const SUPABASE_ANON_KEY =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ1ZnJ4cWlhcGFudmVmc3dycGlyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc1MDI5MjAsImV4cCI6MjA2MzA3ODkyMH0.rcPaXRUYrWnsL2MLZ26drJsMexBEehPam6mh-q3k7fQ"

export const createServerSupabase = () => {
  const cookieStore = cookies()
  return createServerComponentClient<Database>({
    cookies: () => cookieStore,
    supabaseUrl: SUPABASE_URL,
    supabaseKey: SUPABASE_ANON_KEY,
  })
}
